// src/pages/Products.jsx
import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { motion } from "framer-motion";
import { Search, Grid, List, ArrowRight } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";
import { supabase } from "@/lib/supabase";

const Products = () => {
  const { t, direction, language } = useLanguage();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [viewMode, setViewMode] = useState("grid");
  const [products, setProducts] = useState([]);

  const getFontClass = () =>
    language === "ar" ? "font-arabic" : "font-english";

  const categories = [
    { id: "all", name: t("all") },
    { id: "dates", name: t("dates") },
    { id: "honey", name: t("honey") },
    { id: "nuts", name: t("nuts") },
    { id: "spices", name: t("spices") },
    { id: "Food items", name: t("categoryOthers1") },
    { id: "naturalOils", name: t("categoryOthers2") },
  ];

  useEffect(() => {
    const fetchProducts = async () => {
      const { data, error } = await supabase
        .from("products")
        .select(
          `
          id, category, price, image,
          name, name_en, name_fr,
          description, description_en, description_fr
        `
        )
        .order("created_at", { ascending: false });

      if (error) {
        toast({
          title: t("fetchError"),
          description: error.message,
          variant: "destructive",
        });
        return;
      }

      const localized = data.map((item) => {
        let localizedName = item.name;
        if (language === "en" && item.name_en) localizedName = item.name_en;
        else if (language === "fr" && item.name_fr)
          localizedName = item.name_fr;

        let localizedDesc = item.description || "";
        if (language === "en" && item.description_en)
          localizedDesc = item.description_en;
        else if (language === "fr" && item.description_fr)
          localizedDesc = item.description_fr;

        return { ...item, name: localizedName, description: localizedDesc };
      });

      setProducts(localized);
    };

    fetchProducts();
  }, [t, language]);

  const filteredProducts = products.filter((product) => {
    const matchesSearch = product.name
      .toLowerCase()
      .includes(searchTerm.toLowerCase());
    const matchesCategory =
      selectedCategory === "all" || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <>
      <Helmet>
        <title>{t("products")} – Dania Spices</title>
        <meta name="description" content={t("productsSubtitle")} />
      </Helmet>

      <div className="min-h-screen pt-16">
        {/* Header */}
        <section className="py-12 bg-gradient-to-r from-sand-beige via-ivory-white to-sand-beige border-b border-light-gray/30 dark:from-dark-wood dark:via-dark-wood/90 dark:to-dark-wood dark:border-light-gray/10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1
                className={`text-4xl md:text-5xl font-bold text-dark-wood dark:text-ivory-white mb-4 ${getFontClass()}`}
              >
                {t("productsTitle")}
              </h1>
              <div className="mx-auto w-24 h-1 bg-gradient-to-r from-gold-accent to-amber-500 rounded-full mb-6" />
              <p
                className={`text-xl text-charcoal-black/80 dark:text-ivory-white/80 max-w-2xl mx-auto ${getFontClass()}`}
              >
                {t("productsSubtitle")}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Search & View Toggle */}
        <section className="py-8 bg-gradient-to-b from-ivory-white to-sand-beige/30 border-b border-light-gray/30 dark:from-dark-wood/90 dark:to-dark-wood/70 dark:border-light-gray/10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row gap-4 items-center justify-between border-b border-light-gray/20 pb-6 mb-6 dark:border-light-gray/10">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground dark:text-ivory-white/60" />
                <Input
                  type="text"
                  placeholder={t("search")}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={`pl-10 bg-white/80 backdrop-blur-sm border border-light-gray/30 rounded-xl shadow-sm dark:bg-dark-wood/80 dark:border-light-gray/20 dark:text-ivory-white ${getFontClass()}`}
                />
              </div>

              <div className="flex items-center gap-2">
                <Button
                  onClick={() => setViewMode("grid")}
                  variant={viewMode === "grid" ? "default" : "outline"}
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  onClick={() => setViewMode("list")}
                  variant={viewMode === "list" ? "default" : "outline"}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
              <TabsList className="flex min-w-full justify-evenly space-x-2 bg-white dark:bg-[#422b1f] rounded-xl shadow-sm dark:border-light-gray/10 dark:shadow-2xl">
                {categories.map((cat) => (
                  <TabsTrigger
                    key={cat.id}
                    value={cat.id}
                    className={`px-4 py-2 text-sm lg:text-base data-[state=active]:bg-gold-accent data-[state=active]:text-white rounded-lg ${getFontClass()}`}
                  >
                    {cat.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>
        </section>

        {/* Products Display */}
        <section className="py-12 bg-gradient-to-b from-sand-beige/20 to-ivory-white border-b border-light-gray/30 dark:from-dark-wood/70 dark:to-dark-wood/90 dark:border-light-gray/10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            {filteredProducts.length === 0 ? (
              <p
                className={`text-center text-lg text-muted-foreground dark:text-ivory-white/70 ${getFontClass()}`}
              >
                {t("noProductsFound")}
              </p>
            ) : viewMode === "grid" ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((product, idx) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: idx * 0.1 }}
                  >
                    <Card className="h-full bg-white/90 border border-light-gray/20 dark:bg-dark-wood/90 dark:border-light-gray/10 shadow-lg hover:shadow-xl transition">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-48 object-cover"
                      />
                      <CardContent className="p-6">
                        <h3
                          className={`text-lg font-semibold text-dark-wood dark:text-ivory-white mb-2 ${getFontClass()}`}
                        >
                          {product.name}
                        </h3>
                        <p
                          className={`text-charcoal-black/70 dark:text-ivory-white/70 mb-4 ${getFontClass()}`}
                        >
                          {product.description}
                        </p>
                        <span
                          className={`text-lg font-bold text-gold-accent ${getFontClass()}`}
                        >
                          {product.price}
                        </span>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredProducts.map((product, idx) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: idx * 0.1 }}
                  >
                    <Card className="bg-white/90 border border-light-gray/20 dark:bg-dark-wood/90 dark:border-light-gray/10 shadow-lg hover:shadow-xl transition">
                      <div className="flex items-center p-6 space-x-8 rtl:space-x-reverse">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-24 h-24 object-cover rounded-lg"
                        />
                        <div className="flex-1">
                          <h3
                            className={`text-lg font-semibold text-dark-wood dark:text-ivory-white mb-2 ${getFontClass()}`}
                          >
                            {product.name}
                          </h3>
                          <p
                            className={`text-charcoal-black/70 dark:text-ivory-white/70 mb-2 ${getFontClass()}`}
                          >
                            {product.description}
                          </p>
                          <span
                            className={`text-lg font-bold text-gold-accent ${getFontClass()}`}
                          >
                            {product.price}
                          </span>
                        </div>
                        <ArrowRight
                          className={`h-5 w-5 text-dark-wood dark:text-ivory-white ml-4 ${
                            direction === "rtl" ? "rotate-180" : ""
                          }`}
                        />
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </section>
      </div>
    </>
  );
};

export default Products;
