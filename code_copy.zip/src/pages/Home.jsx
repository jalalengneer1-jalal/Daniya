// src/pages/Home.jsx

import React, { Suspense, useMemo } from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Leaf, Award } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "react-query";
import { supabase } from "@/lib/supabase";

// Lazy load AdvertisementSlider
const AdvertisementSlider = React.lazy(() =>
  import("@/components/AdvertisementSlider")
);

// Skeleton loader while waiting for products
const SkeletonCard = () => (
  <div className="animate-pulse space-y-4 p-6 bg-white/90 backdrop-blur-sm rounded-lg">
    <div className="h-48 bg-gray-200 rounded"></div>
    <div className="h-6 bg-gray-200 rounded w-3/4"></div>
    <div className="h-4 bg-gray-200 rounded w-full"></div>
    <div className="h-4 bg-gray-200 rounded w-1/2"></div>
  </div>
);

// Get product name by language
const getProductName = (prod, language) => {
  switch (language) {
    case "en":
      return prod.name_en?.trim() || prod.name;
    case "fr":
      return prod.name_fr?.trim() || prod.name;
    default:
      return prod.name;
  }
};

// Memoized Product Card with translation hook
const ProductCard = React.memo(({ prod, language, direction }) => {
  const { t } = useLanguage();
  const name = getProductName(prod, language);
  return (
    <Card className="product-card hover-lift group cursor-pointer h-full bg-white/90 backdrop-blur-sm border border-light-gray/20 shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden dark:bg-dark-wood/90 dark:border-light-gray/10 dark:shadow-2xl dark:hover:shadow-3xl">
      <Link to={`/products`}>
        <div className="relative overflow-hidden rounded-t-lg border-b border-light-gray/10 dark:border-light-gray/5">
          <img
            src={prod.image}
            loading="lazy"
            decoding="async"
            alt={name}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full p-2 shadow-md dark:bg-dark-wood/90 dark:shadow-2xl">
            <ArrowRight
              className={`h-4 w-4 text-dark-wood dark:text-ivory-white ${
                direction === "rtl" ? "rotate-180" : ""
              }`}
            />
          </div>
        </div>
        <CardContent className="p-6">
          <h3 className="text-xl font-semibold text-dark-wood dark:text-ivory-white mb-2">
            {name}
          </h3>
          <p className="text-charcoal-black/70 dark:text-ivory-white/70 mb-4 leading-relaxed">
            {prod.description}
          </p>
          <p className="text-lg font-bold text-gold-accent mb-4">
            {prod.price} {t("fdj")}
          </p>
          <Button
            variant="outline"
            size="sm"
            className="w-full rounded-lg bg-white/80 backdrop-blur-sm border-light-gray/30 hover:bg-gold-accent hover:text-white transition-all duration-300 dark:bg-dark-wood/80 dark:border-light-gray/20 dark:text-ivory-white dark:hover:bg-gold-accent dark:hover:text-white"
          >
            {t("viewDetails")}
          </Button>
        </CardContent>
      </Link>
    </Card>
  );
});

const Home = () => {
  const { t, direction, language } = useLanguage();

  // Fetch advertisements
  const {
    data: ads,
    isLoading: adsLoading,
    error: adsError,
  } = useQuery(
    "ads",
    async () => {
      const { data, error } = await supabase
        .from("advertisements")
        .select("id, link, image_url")
        .order("created_at", { ascending: false });
      if (error) throw new Error(error.message);
      return data.map(({ id, link, image_url }) => ({
        id,
        link,
        image: image_url,
      }));
    },
    { staleTime: 300000 }
  );

  // Fetch products without 'currency' column
  const {
    data: products,
    isLoading: productsLoading,
    error: productsError,
  } = useQuery(
    "products",
    async () => {
      const { data, error } = await supabase
        .from("products")
        .select(
          "id, name, name_en, name_fr, category, price, description, image"
        )
        .order("created_at", { ascending: false });
      if (error) throw new Error(error.message);
      return data;
    },
    { staleTime: 300000 }
  );

  const productList = useMemo(() => products || [], [products]);

  return (
    <>
      <Helmet>
        <title>{t("welcomeTitle")} – Daniya Spices</title>
        <meta name="description" content={t("welcomeSubtitle")} />
      </Helmet>

      <div className="pt-16 min-h-screen">
        {/* Hero + Slider */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden hero-pattern border-b border-light-gray/20 dark:border-light-gray/10">
          <div className="absolute inset-0 bg-gradient-to-br from-amber-500/20 via-orange-500/20 to-dark-wood/20 dark:from-amber-500/10 dark:via-orange-500/10 dark:to-dark-wood/10" />

          <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: direction === "rtl" ? 50 : -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                className="text-center lg:text-left"
              >
                <h1 className="text-4xl md:text-6xl font-bold text-foreground dark:text-ivory-white mb-6 text-shadow">
                  {t("welcomeTitle")}
                </h1>
                <p className="text-xl md:text-2xl text-muted-foreground dark:text-ivory-white/90 mb-8 leading-relaxed">
                  {t("welcomeSubtitle")}
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                  <Button
                    asChild
                    size="lg"
                    className="spice-gradient text-white shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    <Link to="/products">
                      {t("exploreProducts")}
                      <ArrowRight
                        className={`ml-2 h-5 w-5 ${
                          direction === "rtl" ? "rotate-180" : ""
                        }`}
                      />
                    </Link>
                  </Button>
                  <Button
                    asChild
                    variant="outline"
                    size="lg"
                    className="border-light-gray/30 bg-white/80 backdrop-blur-sm hover:bg-gold-accent hover:text-white transition-all duration-300"
                  >
                    <Link to="/about">{t("learnMore")}</Link>
                  </Button>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="relative"
              >
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 border border-light-gray/20 shadow-lg dark:bg-dark-wood/20 dark:border-light-gray/10 dark:shadow-2xl">
                  <Suspense
                    fallback={
                      <div className="h-64 flex items-center justify-center">
                        Loading slider...
                      </div>
                    }
                  >
                    {adsLoading ? (
                      <div className="h-64 flex items-center justify-center">
                        Loading...
                      </div>
                    ) : adsError ? (
                      <div className="text-red-500">Failed to load ads</div>
                    ) : (
                      <AdvertisementSlider advertisements={ads} />
                    )}
                  </Suspense>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Products Grid */}
        <section className="py-20 bg-gradient-to-b from-background to-secondary/20 border-b border-light-gray/10 dark:from-dark-wood dark:to-dark-wood/80 dark:border-light-gray/5">
          <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <div className="inline-block w-24 h-1 bg-gradient-to-r from-gold-accent to-amber-500 rounded-full mb-6" />
              <h2 className="text-3xl md:text-4xl font-bold text-foreground dark:text-ivory-white mb-4">
                {t("productsTitle")}
              </h2>
              <p className="text-xl text-muted-foreground dark:text-ivory-white/80 max-w-2xl mx-auto">
                {t("productsSubtitle")}
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {productsLoading
                ? Array.from({ length: 6 }).map((_, i) => (
                    <SkeletonCard key={i} />
                  ))
                : productList.map((prod, idx) => (
                    <motion.div
                      key={prod.id}
                      initial={{ opacity: 0, y: 50 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.6, delay: idx * 0.1 }}
                      viewport={{ once: true }}
                    >
                      <ProductCard
                        prod={prod}
                        language={language}
                        direction={direction}
                      />
                    </motion.div>
                  ))}
            </div>
            {productsError && (
              <div className="text-red-500 mt-6">فشل في تحميل المنتجات</div>
            )}
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="py-20 bg-gradient-to-r from-sand-beige via-ivory-white to-sand-beige dark:from-dark-wood dark:via-dark-wood/90 dark:to-dark-wood dark:border-light-gray/5">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <div className="inline-block w-24 h-1 bg-gradient-to-r from-gold-accent to-amber-500 rounded-full mb-6" />
              <h2 className="text-3xl md:text-4xl font-bold text-dark-wood dark:text-ivory-white mb-4">
                {t("whyChooseUs")}
              </h2>
              <p className="text-xl text-charcoal-black/80 dark:text-ivory-white/80 max-w-2xl mx-auto">
                {t("whyChooseUsDesc")}
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
              {[
                {
                  icon: Leaf,
                  titleKey: "natural",
                  descKey: "naturalDescription",
                },
                {
                  icon: Award,
                  titleKey: "quality",
                  descKey: "qualityDescription",
                },
              ].map(({ icon: Icon, titleKey, descKey }, idx) => (
                <motion.div
                  key={titleKey}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: idx * 0.1 }}
                  viewport={{ once: true }}
                  className="text-center group"
                >
                  <Card className="bg-white/80 backdrop-blur-sm border border-light-gray/20 shadow-lg hover:shadow-xl transition-all duration-300 p-6 relative overflow-hidden dark:bg-dark-wood/80 dark:border-light-gray/10 dark:shadow-2xl dark:hover:shadow-3xl">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-gold-accent to-amber-500"></div>
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-gold-accent to-amber-500 rounded-full mb-4 group-hover:scale-110 transition-transform duration-300 shadow-md">
                      <Icon className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-dark-wood dark:text-ivory-white mb-2">
                      {t(titleKey)}
                    </h3>
                    <p className="text-charcoal-black/70 dark:text-ivory-white/70 leading-relaxed">
                      {t(descKey)}
                    </p>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;
