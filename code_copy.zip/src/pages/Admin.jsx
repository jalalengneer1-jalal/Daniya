// src/pages/Admin/Admin.jsx
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import AdminStats from '@/pages/Admin/AdminStats';
import ProductManagement from '@/pages/Admin/ProductManagement';
import GalleryManagement from '@/pages/Admin/GalleryManagement';
import AdvertisementManagement from '@/pages/Admin/AdvertisementManagement';
import ContactMessages from '@/pages/Admin/ContactMessages';
import { Package, Users, Image as ImageIcon, Megaphone } from 'lucide-react';
import { supabase } from '@/lib/supabase'; 

const Admin = () => {
  const { t, language } = useLanguage();
  const [statsData, setStatsData] = useState({
    products: 0,
    contacts: 0,
    gallery: 0,
    advertisements: 0,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const getFontClass = () => language === 'ar' ? 'font-arabic' : 'font-english';

  useEffect(() => {
    const fetchCounts = async () => {
      try {
        setLoading(true);
        // استعلامات موازية لجلب عدد السجلات فقط
        const tables = ['products', 'contacts', 'gallery', 'advertisements'];
        const promises = tables.map((table) =>
          supabase
            .from(table)
            .select('*', { head: true, count: 'exact' })
        );
        const results = await Promise.all(promises);

        const newStats = {};
        results.forEach((res, idx) => {
          if (res.error) throw res.error;
          newStats[tables[idx]] = res.count || 0;
        });

        setStatsData(newStats);
      } catch (err) {
        console.error('Error fetching counts:', err);
        setError('فشل في جلب البيانات. حاول لاحقًا.');
      } finally {
        setLoading(false);
      }
    };

    fetchCounts();
  }, []);

  // إعداد المصفوفة الديناميكية للإحصائيات
  const stats = [
    {
      title: t('totalProducts'),
      value: statsData.products,
      icon: Package,
      color: 'from-gold-accent to-amber-500',
    },
    {
      title: t('contactMessages'),
      value: statsData.contacts,
      icon: Users,
      color: 'from-gold-accent to-amber-500',
    },
    {
      title: t('galleryImages'),
      value: statsData.gallery,
      icon: ImageIcon,
      color: 'from-gold-accent to-amber-500',
    },
    {
      title: t('advertisements'),
      value: statsData.advertisements,
      icon: Megaphone,
      color: 'from-gold-accent to-amber-500',
    },
  ];

  return (
    <>
      <Helmet>
        <title>{t('admin')} - Daniya Spices</title>
        <meta name="description" content="Admin panel for managing Daniya Spices website" />
      </Helmet>

      <div className="min-h-screen pt-16">
        {/* البانر العلوي */}
        <section className="py-12 bg-gradient-to-r from-sand-beige via-ivory-white to-sand-beige border-b border-light-gray/30 dark:from-dark-wood dark:via-dark-wood/90 dark:to-dark-wood dark:border-light-gray/10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              <h1 className={`text-4xl md:text-5xl font-bold mb-4 ${getFontClass()} text-dark-wood dark:text-ivory-white`}>
                {t('adminTitle')}
              </h1>
              <div className="mx-auto w-24 h-1 bg-gradient-to-r from-gold-accent to-amber-500 rounded-full mb-6" />
              <p className={`text-xl max-w-2xl mx-auto ${getFontClass()} text-charcoal-black/80 dark:text-ivory-white/80`}>
                {t('manageWebsiteContent')}
              </p>
            </motion.div>
          </div>
        </section>

        {/* عرض الإحصائيات أو حالة التحميل/الخطأ */}
        {loading ? (
          <div className="text-center py-8">{t('loading')}...</div>
        ) : error ? (
          <div className="text-center py-8 text-red-500">{error}</div>
        ) : (
          <AdminStats stats={stats} />
        )}

        {/* التبويبات */}
        <section className="py-12 bg-gradient-to-b from-ivory-white to-sand-beige/30 border-b border-light-gray/30 dark:from-dark-wood/90 dark:to-dark-wood/70 dark:border-light-gray/10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <Tabs defaultValue="products" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4 bg-white/80 backdrop-blur-sm border border-light-gray/30 rounded-xl shadow-sm dark:bg-dark-wood/80 dark:border-light-gray/20 dark:shadow-2xl">
                <TabsTrigger value="products" className={`text-sm rounded-lg ${getFontClass()} data-[state=active]:bg-gold-accent data-[state=active]:text-white`}>
                  {t('manageProducts')}
                </TabsTrigger>
                <TabsTrigger value="advertisements" className={`text-sm rounded-lg ${getFontClass()} data-[state=active]:bg-gold-accent data-[state=active]:text-white`}>
                  {t('advertisementManagement')}
                </TabsTrigger>
                <TabsTrigger value="gallery" className={`text-sm rounded-lg ${getFontClass()} data-[state=active]:bg-gold-accent data-[state=active]:text-white`}>
                  {t('galleryManagement')}
                </TabsTrigger>
                <TabsTrigger value="contacts" className={`text-sm rounded-lg ${getFontClass()} data-[state=active]:bg-gold-accent data-[state=active]:text-white`}>
                  {t('contactMessages')}
                </TabsTrigger>
              </TabsList>

              <TabsContent value="products">
                <ProductManagement />
              </TabsContent>
              <TabsContent value="advertisements">
                <AdvertisementManagement />
              </TabsContent>
              <TabsContent value="gallery">
                <GalleryManagement />
              </TabsContent>
              <TabsContent value="contacts">
                <ContactMessages />
              </TabsContent>
            </Tabs>
          </div>
        </section>
      </div>
    </>
  );
};

export default Admin;
