// src/pages/Contact.jsx
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MapPin, Phone, Mail, Clock, Globe, Send } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';

const Contact = () => {
  const { t, language } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });

  const getFontClass = () => language === 'ar' ? 'font-arabic' : 'font-english';

  // URL لعرض الخريطة داخل iframe
  const mapEmbedUrl = "https://www.google.com/maps/embed/v1/place?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&q=H4RW%2BR58+Centre+Commercial,+Al+Hamoudi,+Djibouti";
  // رابط خارجي لفتح الخريطة في Google Maps مباشرة
  const mapLink = "https://www.google.com/maps/search/?api=1&query=H4RW+R58+Centre+Commercial,Al+Hamoudi,Djibouti";
  // موقعكم الإلكتروني
  const websiteUrl = "https://daniaspices.com";

  const contactInfo = [
    {
      icon: MapPin,
      title: t('addressTitle'),
      details: [
        { text: t('address'), href: mapLink }
      ]
    },
    {
      icon: Phone,
      title: t('phoneTitle'),
      details: [
        { text: t('phone'), href: `tel:${t('phone')}` }
      ]
    },
    {
      icon: Mail,
      title: t('emailTitle'),
      details: [
        { text: t('storeEmail'), href: `mailto:${t('storeEmail')}` }
      ]
    },
    // {
    //   icon: Globe,
    //   title: t('websiteTitle'),
    //   details: [
    //     { text: websiteUrl, href: websiteUrl }
    //   ]
    // },
    {
      icon: Clock,
      title: t('workingHoursTitle'),
      details: [
        { text: t('workingHours'), href: null }
      ]
    }
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const { error } = await supabase
      .from('contacts')
      .insert([{
        name:    formData.name,
        email:   formData.email,
        phone:   formData.phone,
        message: formData.message
      }]);

    if (error) {
      toast({
        title: t('sendError') || 'Error',
        description: error.message,
        variant: 'destructive'
      });
    } else {
      toast({
        title: t('messageSentSuccess'),
        description: t('willContactSoon'),
        duration: 5000
      });
      setFormData({ name: '', email: '', phone: '', message: '' });
    }
  };

  return (
    <>
      <Helmet>
        <title>{t('contact')} – Daniya Spices</title>
        <meta name="description" content={t('contactSubtitle')} />
      </Helmet>

      <div className="min-h-screen pt-16">
        {/* Header */}
        <section className="py-12 bg-gradient-to-r from-sand-beige via-ivory-white to-sand-beige border-b border-light-gray/30 dark:from-dark-wood dark:via-dark-wood/90 dark:to-dark-wood dark:border-light-gray/10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              <h1 className={`text-4xl md:text-5xl font-bold text-dark-wood dark:text-ivory-white mb-4 ${getFontClass()}`}>
                {t('contactTitle')}
              </h1>
              <div className="mx-auto w-24 h-1 bg-gradient-to-r from-gold-accent to-amber-500 rounded-full mb-6" />
              <p className={`text-xl text-charcoal-black/80 dark:text-ivory-white/80 max-w-2xl mx-auto ${getFontClass()}`}>
                {t('contactSubtitle')}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Form & Info */}
        <section className="py-20 bg-gradient-to-b from-ivory-white to-sand-beige/30 border-b border-light-gray/30 dark:from-dark-wood/90 dark:to-dark-wood/70 dark:border-light-gray/10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Form */}
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Card className="bg-white/90 backdrop-blur-sm border-2 border-light-gray/30 shadow-xl rounded-2xl dark:bg-dark-wood/90 dark:border-light-gray/10 dark:shadow-2xl">
                  <CardHeader>
                    <CardTitle className={`text-2xl text-dark-wood dark:text-ivory-white ${getFontClass()}`}>
                      {t('sendMessage')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div>
                        <Label htmlFor="name" className={`text-dark-wood dark:text-ivory-white ${getFontClass()}`}>
                          {t('name')}
                        </Label>
                        <Input
                          id="name"
                          name="name"
                          type="text"
                          value={formData.name}
                          onChange={handleChange}
                          required
                          className={`mt-1 bg-white/80 backdrop-blur-sm border border-light-gray/30 dark:bg-dark-wood/80 dark:border-light-gray/20 dark:text-ivory-white dark:placeholder:text-ivory-white/60 ${getFontClass()}`}
                        />
                      </div>

                      <div>
                        <Label htmlFor="email" className={`text-dark-wood dark:text-ivory-white ${getFontClass()}`}>
                          {t('email')}
                        </Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleChange}
                          required
                          className={`mt-1 bg-white/80 backdrop-blur-sm border border-light-gray/30 dark:bg-dark-wood/80 dark:border-light-gray/20 dark:text-ivory-white dark:placeholder:text-ivory-white/60 ${getFontClass()}`}
                        />
                      </div>

                      <div>
                        <Label htmlFor="phone" className={`text-dark-wood dark:text-ivory-white ${getFontClass()}`}>
                          {t('phoneOptional')}
                        </Label>
                        <Input
                          id="phone"
                          name="phone"
                          type="tel"
                          value={formData.phone}
                          onChange={handleChange}
                          className={`mt-1 bg-white/80 backdrop-blur-sm border border-light-gray/30 dark:bg-dark-wood/80 dark:border-light-gray/20 dark:text-ivory-white dark:placeholder:text-ivory-white/60 ${getFontClass()}`}
                        />
                      </div>

                      <div>
                        <Label htmlFor="message" className={`text-dark-wood dark:text-ivory-white ${getFontClass()}`}>
                          {t('message')}
                        </Label>
                        <Textarea
                          id="message"
                          name="message"
                          value={formData.message}
                          onChange={handleChange}
                          required
                          rows={5}
                          className={`mt-1 bg-white/80 backdrop-blur-sm border border-light-gray/30 dark:bg-dark-wood/80 dark:border-light-gray/20 dark:text-ivory-white dark:placeholder:text-ivory-white/60 ${getFontClass()}`}
                        />
                      </div>

                      <Button
                        type="submit"
                        className={`w-full bg-gold-accent text-white hover:bg-dark-wood transition-colors rounded-lg shadow-sm dark:hover:bg-amber-600 ${getFontClass()}`}
                      >
                        <Send className="h-4 w-4 mr-2" />
                        {t('send')}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Contact Info */}
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="space-y-6"
              >
                {contactInfo.map((info, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: idx * 0.1 }}
                  >
                    <Card className="bg-white/90 backdrop-blur-sm border-2 border-light-gray/30 shadow-xl rounded-2xl hover-lift transition-all duration-300 dark:bg-dark-wood/90 dark:border-light-gray/10 dark:shadow-2xl dark:hover:shadow-3xl">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 bg-gradient-to-br from-gold-accent to-amber-500 rounded-full flex items-center justify-center shadow-md">
                            <info.icon className="h-6 w-6 text-white" />
                          </div>
                          <div>
                            <h3 className={`text-lg font-semibold mb-2 ${getFontClass()}`}>
                              {info.title}
                            </h3>
                            {info.details.map((d, i) => (
                              d.href
                                ? (
                                  <a
                                    key={i}
                                    href={d.href}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className={`block underline hover:no-underline text-gold-accent dark:text-amber-400 ${getFontClass()}`}
                                  >
                                    {d.text}
                                  </a>
                                )
                                : (
                                  <p
                                    key={i}
                                    className={`text-charcoal-black/80 dark:text-ivory-white/80 ${getFontClass()}`}
                                  >
                                    {d.text}
                                  </p>
                                )
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            </div>
          </div>
        </section>

        {/* Map */}
        <section className="py-20 bg-gradient-to-r from-sand-beige via-ivory-white to-sand-beige border-b border-light-gray/30 dark:from-dark-wood dark:via-dark-wood/90 dark:to-dark-wood dark:border-light-gray/10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className={`text-3xl md:text-4xl font-bold mb-4 ${getFontClass()}`}>
                {t('ourLocation')}
              </h2>
              <div className="mx-auto w-24 h-1 bg-gradient-to-r from-gold-accent to-amber-500 rounded-full mb-6" />
              <p className={`text-xl mb-8 ${getFontClass()}`}>
                {t('visitUs')}
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="rounded-2xl overflow-hidden shadow-2xl border border-light-gray/20 dark:border-light-gray/10"
            >
              <iframe
                src={mapEmbedUrl}
                width="100%"
                height="400"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-96"
              />
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Contact;
