// src/pages/Gallery.jsx
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Image as ImageIcon } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';

const Gallery = () => {
  const { t, language } = useLanguage();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [items, setItems] = useState([]);

  const getFontClass = () =>
    language === 'ar' ? 'font-arabic' : 'font-english';

  const categories = [
    { id: 'all',      name: t('all') },
    { id: 'products', name: t('productsCategory') },
    { id: 'events',   name: t('eventsCategory') }
  ];

  useEffect(() => {
    const fetchGallery = async () => {
      const { data, error } = await supabase
        .from('gallery')
        .select(`
          id,
          category,
          storage_path,
          media_type,
          title,
          translation_en,
          translation_fr
        `)
        .order('created_at', { ascending: false });

      if (error) {
        toast({
          title: t('fetchError'),
          description: error.message,
          variant: 'destructive'
        });
        return;
      }

      const withUrls = data.map(item => {
        const { data: pub } = supabase
          .storage
          .from('gallery')
          .getPublicUrl(item.storage_path);

        // اختيار العنوان حسب لغة الصفحة
        let localizedTitle = item.title;
        if (language === 'en' && item.translation_en) {
          localizedTitle = item.translation_en;
        } else if (language === 'fr' && item.translation_fr) {
          localizedTitle = item.translation_fr;
        }

        return {
          id: item.id,
          category: item.category,
          title: localizedTitle,
          url: pub.publicUrl,
          media_type: item.media_type
        };
      });

      setItems(withUrls);
    };

    fetchGallery();
  }, [t, language]); // إضافة language هنا

  const filteredItems =
    selectedCategory === 'all'
      ? items
      : items.filter(i => i.category === selectedCategory);

  return (
    <>
      <Helmet>
        <title>{t('gallery')} - Daniya Spices</title>
        <meta name="description" content={t('gallerySubtitle')} />
      </Helmet>

      <div className="min-h-screen pt-16">
        {/* مقدمة الصفحة */}
        <section className="py-12 bg-gradient-to-r from-sand-beige via-ivory-white to-sand-beige border-b border-light-gray/30 dark:from-dark-wood dark:via-dark-wood/90 dark:to-dark-wood dark:border-light-gray/10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              <h1 className={`text-4xl md:text-5xl font-bold text-dark-wood dark:text-ivory-white mb-4 ${getFontClass()}`}>
                {t('galleryTitle')}
              </h1>
              <div className="mx-auto w-24 h-1 bg-gradient-to-r from-gold-accent to-amber-500 rounded-full mb-6"></div>
              <p className={`text-xl text-charcoal-black/80 dark:text-ivory-white/80 max-w-2xl mx-auto ${getFontClass()}`}>
                {t('gallerySubtitle')}
              </p>
            </motion.div>
          </div>
        </section>

        {/* تبويبات الفلترة */}
        <section className="py-8 bg-gradient-to-b from-ivory-white to-sand-beige/30 border-b border-light-gray/30 dark:from-dark-wood/90 dark:to-dark-wood/70 dark:border-light-gray/10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
              <TabsList className="grid w-full grid-cols-3 bg-white/80 backdrop-blur-sm border border-light-gray/30 rounded-xl shadow-sm dark:bg-dark-wood/80 dark:border-light-gray/10 dark:shadow-2xl">
                {categories.map(cat => (
                  <TabsTrigger
                    key={cat.id}
                    value={cat.id}
                    className={`text-xs lg:text-sm text-dark-wood dark:text-ivory-white data-[state=active]:bg-gold-accent data-[state=active]:text-white rounded-lg ${getFontClass()}`}
                  >
                    {cat.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>
        </section>

        {/* شبكة المعرض */}
        <section className="py-12 bg-gradient-to-b from-sand-beige/20 to-ivory-white border-b border-light-gray/30 dark:from-dark-wood/70 dark:to-dark-wood/90 dark:border-light-gray/10">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            >
              {filteredItems.map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="group cursor-pointer"
                >
                  <div className="relative overflow-hidden rounded-2xl border-2 border-light-gray/30 shadow-xl hover:shadow-2xl bg-white/90 backdrop-blur-sm hover-lift transition-all duration-300 dark:bg-dark-wood/90 dark:border-light-gray/10 dark:shadow-2xl dark:hover:shadow-3xl">
                    {item.media_type === 'image' ? (
                      <img
                        src={item.url}
                        alt={item.title}
                        className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500 rounded-t-2xl"
                        onError={e => { e.target.style.display = 'none'; }}
                      />
                    ) : (
                      <video
                        src={item.url}
                        autoPlay
                        loop
                        muted
                        playsInline
                        className="w-full h-64 object-cover rounded-t-2xl"
                      />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-t-2xl">
                      <div className="absolute bottom-4 left-4 right-4 text-white">
                        <h3 className={`text-lg font-semibold mb-1 ${getFontClass()}`}>
                          {item.title}
                        </h3>
                      </div>
                    </div>
                    <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 border border-light-gray/30 shadow-sm dark:bg-dark-wood/90 dark:border-light-gray/20 dark:shadow-2xl">
                      <ImageIcon className="h-4 w-4 text-charcoal-black dark:text-ivory-white" />
                    </div>
                    <div className="absolute inset-0 flex items-center justify-center bg-muted/50 hidden rounded-2xl dark:bg-dark-wood/50">
                      <div className="text-center">
                        <ImageIcon className="h-8 w-8 text-muted-foreground dark:text-ivory-white/60 mx-auto mb-2" />
                        <p className={`text-sm text-muted-foreground dark:text-ivory-white/70 ${getFontClass()}`}>
                          {t('cannotDisplayImage')}
                        </p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>

            {filteredItems.length === 0 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-12">
                <p className={`text-xl text-muted-foreground dark:text-ivory-white/70 ${getFontClass()}`}>
                  {t('noMediaInCategory')}
                </p>
              </motion.div>
            )}
          </div>
        </section>
      </div>
    </>
  );
};

export default Gallery;
