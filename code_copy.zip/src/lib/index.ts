
// import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
// import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

// // أنشئ عميل Supabase إذا كنت تستخدمه داخل الـ Function (اختياري)
// const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
// const SUPABASE_SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
// const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

// serve(async (req) => {
//   // 1) تعامل مع طلبات preflight (CORS)
//   if (req.method === 'OPTIONS') {
//     return new Response(null, {
//       status: 204,
//       headers: {
//         'Access-Control-Allow-Origin': '*',                  // أو بدل '*' بنطاقك
//         'Access-Control-Allow-Methods': 'POST, OPTIONS',
//         'Access-Control-Allow-Headers': 'Content-Type, Authorization',
//       },
//     });
//   }

//   // 2) تحقق من الطريقة
//   if (req.method !== 'POST') {
//     return new Response('Method Not Allowed', { status: 405 });
//   }

//   try {
//     const { text, target_languages } = await req.json();
//     if (!text || !Array.isArray(target_languages)) {
//       return new Response(JSON.stringify({ error: 'Invalid payload' }), {
//         status: 400,
//         headers: {
//           'Content-Type': 'application/json',
//           'Access-Control-Allow-Origin': '*',
//         },
//       });
//     }

//     // مثال: استخدام OpenAI API لترجمة النص
//     const OPENAI_KEY = Deno.env.get('OPENAI_API_KEY')!;
//     const response = await fetch('https://api.openai.com/v1/chat/completions', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//         'Authorization': `Bearer ${OPENAI_KEY}`,
//       },
//       body: JSON.stringify({
//         model: 'gpt-3.5-turbo',
//         messages: [
//           { role: 'system', content: 'You are a translation assistant.' },
//           { role: 'user', content: `Translate the following text into ${target_languages.join(' and ')}: "${text}"` }
//         ],
//         temperature: 0.2,
//       }),
//     });

//     if (!response.ok) {
//       const errText = await response.text();
//       throw new Error(`OpenAI error: ${errText}`);
//     }

//     const { choices } = await response.json() as any;
//     const translated = choices[0].message.content as string;

//     // نفترض أن الرد يحتوي على قسمين مفصولين بعلامة معينة، أو يمكنك إرسال استعلام لكل لغة على حدة
//     // على سبيل المثال: "en: Hello\nfr: Bonjour"
//     const lines = translated.split('\n');
//     const result: Record<string,string> = {};
//     for (const line of lines) {
//       const [lang, ...rest] = line.split(':');
//       if (lang && rest.length) {
//         result[lang.trim()] = rest.join(':').trim();
//       }
//     }

//     return new Response(JSON.stringify(result), {
//       status: 200,
//       headers: {
//         'Content-Type': 'application/json',
//         'Access-Control-Allow-Origin': '*',
//       },
//     });
//   } catch (err: any) {
//     console.error('Translation function error:', err);
//     return new Response(JSON.stringify({ error: err.message }), {
//       status: 500,
//       headers: {
//         'Content-Type': 'application/json',
//         'Access-Control-Allow-Origin': '*',
//       },
//     });
//   }
// });
