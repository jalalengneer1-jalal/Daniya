// src/pages/AdvertisementSlider.jsx
import React, { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, Play, Pause } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/lib/supabase";

const AdvertisementSlider = () => {
  const { t, language } = useLanguage();
  const [ads, setAds] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [loading, setLoading] = useState(true);
  const [imageStatus, setImageStatus] = useState("loading"); // 'loading', 'loaded', 'error'
  const intervalRef = useRef(null);

  // Fetch all ads at once
  useEffect(() => {
    const fetchAds = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from("advertisements")
        .select("id, link, image_url")
        .order("created_at", { ascending: false });

      if (error) {
        console.error("Error fetching ads:", error);
        setAds([]);
      } else {
        setAds(data);
      }
      setLoading(false);
    };

    fetchAds();
  }, []);

  // Auto-play management
  useEffect(() => {
    if (isPlaying && ads.length > 1) {
      intervalRef.current = setInterval(() => {
        setCurrentIndex((i) => (i + 1) % ads.length);
      }, 5000);
    }
    return () => clearInterval(intervalRef.current);
  }, [isPlaying, ads.length]);

  // Reset image status on slide change
  useEffect(() => {
    setImageStatus("loading");
  }, [currentIndex]);

  const goPrev = useCallback(() => {
    setCurrentIndex((i) => (i - 1 + ads.length) % ads.length);
  }, [ads.length]);

  const goNext = useCallback(() => {
    setCurrentIndex((i) => (i + 1) % ads.length);
  }, [ads.length]);

  const togglePlay = useCallback(() => {
    setIsPlaying((p) => !p);
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <svg className="animate-spin h-8 w-8 text-gray-500" viewBox="0 0 24 24">
          <circle
            className="opacity-25"
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            strokeWidth="4"
            fill="none"
          />
          <path
            className="opacity-75"
            fill="currentColor"
            d="M4 12a8 8 0 018-8v4l3-3-3-3v4a8 8 0 100 16v-4l-3 3 3 3v-4a8 8 0 01-8-8z"
          />
        </svg>
      </div>
    );
  }

  if (ads.length === 0) {
    return null;
  }

  const { id, link, image_url } = ads[currentIndex];
  const fontClass = language === "ar" ? "font-arabic" : "font-english";

  return (
    <div
      className="relative w-full overflow-hidden rounded-2xl shadow-lg"
      style={{ aspectRatio: "16 / 9" }}
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={id}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.5 }}
          className="absolute inset-0"
        >
          {imageStatus === "loading" && (
            <div className="flex justify-center items-center h-full bg-black/10">
              <svg
                className="animate-spin h-8 w-8 text-gray-500"
                viewBox="0 0 24 24"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                  fill="none"
                />
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8v4l3-3-3-3v4a8 8 0 100 16v-4l-3 3 3 3v-4a8 8 0 01-8-8z"
                />
              </svg>
            </div>
          )}

          <img
            src={image_url}
            alt={t("advertisement_alt") || "إعلان"}
            className={`w-full h-full object-cover transition-opacity duration-500 
              ${imageStatus === "loaded" ? "opacity-100" : "opacity-0"}`}
            onLoad={() => setImageStatus("loaded")}
            onError={() => setImageStatus("error")}
            onClick={() => window.open(link, "_blank")}
          />

          {imageStatus === "error" && (
            <div className="absolute inset-0 flex flex-col justify-center items-center bg-gray-200">
              <p className={`${fontClass} text-gray-600`}>
                {t("image_load_error")}
              </p>
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {ads.length > 1 && (
        <>
          {/* Navigation buttons */}
          <Button
            onClick={goPrev}
            variant="ghost"
            size="icon"
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white"
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>
          <Button
            onClick={goNext}
            variant="ghost"
            size="icon"
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white"
          >
            <ChevronRight className="h-6 w-6" />
          </Button>

          {/* Play/Pause */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2">
            <Button
              onClick={togglePlay}
              variant="ghost"
              size="icon"
              className="bg-black/30 hover:bg-black/50 text-white"
            >
              {isPlaying ? (
                <Pause className="h-5 w-5" />
              ) : (
                <Play className="h-5 w-5" />
              )}
            </Button>
          </div>

          {/* Dots */}
          <div className="absolute bottom-4 right-4 flex items-center gap-2">
            {ads.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`w-2 h-2 rounded-full transition ${
                  idx === currentIndex
                    ? "bg-white scale-110"
                    : "bg-white/50 hover:bg-white/75"
                }`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default AdvertisementSlider;
